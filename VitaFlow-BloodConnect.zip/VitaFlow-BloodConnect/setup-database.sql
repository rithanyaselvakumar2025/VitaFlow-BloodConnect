-- ==============================================================================
-- BloodConnect – Blood Donor Finder System
-- MySQL 8 Database Setup Script
--
-- How to run this script:
--   Option A: Using MySQL Command Line Client:
--             mysql -u root -p < setup-database.sql
--   Option B: Using MySQL Workbench:
--             Open this file and click the Execute (Lightning bolt) button.
-- ==============================================================================

-- 1. Create database if it does not already exist
CREATE DATABASE IF NOT EXISTS bloodconnect_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE bloodconnect_db;

-- 2. Create 'donors' table
CREATE TABLE IF NOT EXISTS donors (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    blood_group VARCHAR(10) NOT NULL,
    city VARCHAR(50) NOT NULL,
    availability VARCHAR(20) NOT NULL DEFAULT 'Available',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Create 'admins' table for authenticated administrator management
CREATE TABLE IF NOT EXISTS admins (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    role VARCHAR(50) NOT NULL DEFAULT 'ROLE_ADMIN'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Display status confirmation
SELECT 'bloodconnect_db database and tables initialized successfully!' AS status;
