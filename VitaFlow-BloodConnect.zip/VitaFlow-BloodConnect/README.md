# BloodConnect – Blood Donor Finder System

> **A Complete, Beginner-Friendly Full-Stack College Mini-Project**  
> Developed using **Java 21**, **Spring Boot 3.3**, **Spring Data JPA**, **Thymeleaf**, **Bootstrap 5**, and **MySQL 8**.

---

## 1. Project Introduction

**BloodConnect** is an emergency blood donor finder web application built as an academic college mini-project. During critical medical situations, finding compatible blood donors quickly within a specific city can save lives. 

BloodConnect bridges the communication gap between voluntary blood donors and people in urgent need. Donors can register and manage their availability status, while seekers can filter available donors by blood group and city. To protect voluntary donors from unsolicited spam and harassment, sensitive personal contact numbers are kept safe and mediated by the authenticated system administrator.

---

## 2. Project Objectives

- **Rapid Donor Discovery:** Enable users to find available blood donors matching required blood groups and locations in seconds.
- **Voluntary Participation:** Provide a clean, user-friendly registration workflow for community blood donors.
- **Donor Privacy Protection:** Shield donor personal contact numbers from unauthorized public exposure while maintaining emergency accessibility.
- **Centralized Administration:** Allow verified administrators to manage donor availability status and remove records when necessary.
- **Real-Time Accuracy:** Display true database statistics and live search results directly from MySQL without hardcoding or fake counters.

---

## 3. Features

1. **Homepage with Live Counts:**
   - Hero banner and call-to-actions ("Register as Donor", "Find Blood Donors").
   - Real-time statistics queried directly from MySQL (shows 0 when empty).
   - "How It Works" 3-step walkthrough.
   - Blood donation awareness & ABO blood compatibility guide.

2. **Donor Registration:**
   - Input fields: Full Name, Email, Phone Number, Blood Group, City, Availability.
   - Blood groups: `A+`, `A-`, `B+`, `B-`, `AB+`, `AB-`, `O+`, `O-`.
   - Comprehensive validation: empty fields, email format, phone pattern.
   - Duplicate email prevention with user-friendly error feedback.

3. **Find Blood Donors (Public Search):**
   - Filter by Blood Group and/or City (case-insensitive search).
   - Exclusively shows donors marked as **Available**.
   - Graceful empty states when no donors match.
   - Safe contact mediation dialog protecting donor contact information.

4. **Administrator Authentication:**
   - Secure login form at `/login`.
   - BCrypt password hashing and Spring Security role-based access control.
   - Protected routes (`/admin/**`) redirecting unauthenticated requests.
   - Safe session logout with CSRF protection.

5. **Admin Dashboard:**
   - Real-time database metrics: Total Donors, Available Donors, Unavailable Donors.
   - Full donor table displaying names, blood groups, cities, emails, and phone numbers.
   - Instant search/filter donors by Name or City.
   - One-click Availability toggle (`Available` ⟷ `Unavailable`).
   - Safe deletion of donor records with confirmation prompt.

6. **About Page:**
   - Project overview, objectives, technology stack breakdown, system workflow, and medical disclaimer.

---

## 4. Technology Stack

| Layer | Technology | Version | Purpose |
| :--- | :--- | :--- | :--- |
| **Backend** | Java | 21 (LTS) | Core programming language |
| **Framework** | Spring Boot | 3.3.4 | Application framework & dependency injection |
| **Web MVC** | Spring MVC | 6.1.x | HTTP routing, request mapping, and controllers |
| **Security** | Spring Security | 6.3.x | Role-based authorization & BCrypt password hashing |
| **Data Access**| Spring Data JPA / Hibernate | 6.5.x | ORM, queries, and schema generation |
| **Validation** | Jakarta Validation (Hibernate Validator) | 3.0.x | Form validation (`@Email`, `@NotBlank`, etc.) |
| **Template Engine** | Thymeleaf | 3.1.x | Server-rendered dynamic HTML5 templates |
| **Frontend UI**| Bootstrap | 5.3.3 | Responsive grid, cards, and UI components |
| **Icons** | Bootstrap Icons | 1.11.3 | Modern iconography |
| **Database** | MySQL Server | 8.x | Persistent relational database storage |
| **Build Tool** | Apache Maven | 3.9.x | Project build & dependency management |

---

## 5. Software Prerequisites

Before running the application on your computer, ensure the following are installed:

1. **Java Development Kit (JDK 21 or higher):**
   - Check version:
     ```powershell
     java -version
     ```
2. **MySQL Server 8.0+:**
   - Ensure the MySQL service is running on port `3306`.
3. **Apache Maven 3.9+** *(Bundled inside this repository at `./apache-maven-3.9.9` for convenience!)*

---

## 6. How to Create the MySQL Database

Open your MySQL Command Line Client, PowerShell, or MySQL Workbench and run:

### Option A: Using the provided `setup-database.sql` script (Recommended)
```powershell
mysql -u root -p < setup-database.sql
```

### Option B: Running SQL queries manually
```sql
CREATE DATABASE IF NOT EXISTS bloodconnect_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE bloodconnect_db;
```

> **Note:** Spring Boot JPA is configured with `spring.jpa.hibernate.ddl-auto=update`, which automatically generates and updates the `donors` and `admins` tables upon application startup!

---

## 7. How to Configure Database Credentials

BloodConnect uses environment variables with safe fallback defaults in `src/main/resources/application.properties`.

### Default configuration:
- **Database URL:** `jdbc:mysql://localhost:3306/bloodconnect_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC`
- **Username:** `root`
- **Password:** *(empty)*

### Setting credentials via Windows PowerShell:
If your MySQL root password is `MySecretPassword`, run in PowerShell before starting:
```powershell
$env:DB_USERNAME = "root"
$env:DB_PASSWORD = "MySecretPassword"
```

### Or edit `src/main/resources/application.properties` directly:
```properties
spring.datasource.username=root
spring.datasource.password=your_mysql_password
```

---

## 8. How to Configure the Administrator Account

When the application boots for the first time, it automatically creates the default administrator in the MySQL `admins` table with BCrypt hashed credentials.

### Default Administrator Credentials:
- **Username:** `admin`
- **Password:** `Admin@123`

### Customizing Admin Credentials via Environment Variables:
```powershell
$env:ADMIN_USERNAME = "superadmin"
$env:ADMIN_PASSWORD = "MyStrongPassword@2026"
$env:ADMIN_NAME = "Lead Hospital Coordinator"
```

---

## 9. How to Run the Application

### Method 1: Using the Bundled Maven (Windows PowerShell)
```powershell
# 1. Set JAVA_HOME if not already set (e.g. for JDK 21 / 26)
$env:JAVA_HOME = "C:\Program Files\Java\jdk-26.0.1"

# 2. Run Spring Boot
.\apache-maven-3.9.9\bin\mvn.cmd spring-boot:run
```

### Method 2: Running the Pre-Packaged Standalone JAR
```powershell
java -jar target/bloodconnect-1.0.0.jar
```

### Method 3: Using System Maven
```powershell
mvn spring-boot:run
```

---

## 10. Local Website Address

Once the Spring Boot console displays `Started BloodConnectApplication in ... seconds`:

- **Public Website:** [http://localhost:8080/](http://localhost:8080/)
- **Donor Registration:** [http://localhost:8080/register](http://localhost:8080/register)
- **Donor Search:** [http://localhost:8080/search](http://localhost:8080/search)
- **Admin Login:** [http://localhost:8080/login](http://localhost:8080/login)
- **Admin Dashboard:** [http://localhost:8080/admin/dashboard](http://localhost:8080/admin/dashboard)
- **About Page:** [http://localhost:8080/about](http://localhost:8080/about)

---

## 11. How to Use the Website (College Presentation Guide)

### Step 1: Demonstrate the Homepage
- Navigate to `http://localhost:8080/`.
- Show that the donor count starts at `0` (or matching actual DB records).
- Point out the 3-step process, purpose of blood donation, and blood compatibility table.

### Step 2: Register a New Donor
- Click **"Register as Donor"** in the navigation bar.
- Fill out the form with a donor's name, email, phone number, blood group (e.g., `O+`), and city (e.g., `Mumbai`).
- Submit the form and observe the green success alert.
- Attempt to register the exact same email again to demonstrate **duplicate email prevention**.

### Step 3: Search for Blood Donors
- Click **"Find Donors"**.
- Select blood group `O+` and type `mumbai` (showcase case-insensitive search).
- Click **"Search"** to display matching donor cards.
- Click **"Request Contact via Admin"** to explain how donor privacy is protected against spam.

### Step 4: Administrator Management
- Go to **"Admin Login"** (`/login`).
- Enter credentials: `admin` / `Admin@123`.
- View the dashboard statistics: Total Donors, Available Donors, Unavailable Donors.
- Toggle a donor's status from **Available** to **Unavailable**.
- Return to the public search page to prove that the unavailable donor no longer appears in public results!
- Return to the admin dashboard and demonstrate the **Delete** action (with confirmation dialog).

---

## 12. Project Folder Structure

```
FlowVita/
├── apache-maven-3.9.9/             # Bundled portable Maven binary
├── src/
│   ├── main/
│   │   ├── java/com/bloodconnect/
│   │   │   ├── BloodConnectApplication.java   # Spring Boot Application entry point
│   │   │   ├── config/
│   │   │   │   ├── AdminInitializer.java      # Seeds default admin account into MySQL
│   │   │   │   └── SecurityConfig.java        # Spring Security 6 RBAC & Login config
│   │   │   ├── controller/
│   │   │   │   ├── AboutController.java       # Page 6: /about controller
│   │   │   │   ├── AdminController.java       # Page 5: /admin/dashboard & management
│   │   │   │   ├── AuthController.java        # Page 4: /login controller
│   │   │   │   ├── DonorController.java       # Page 2: /register & Page 3: /search
│   │   │   │   ├── GlobalExceptionHandler.java# Centralized friendly error handling
│   │   │   │   └── HomeController.java        # Page 1: / home controller with DB stats
│   │   │   ├── entity/
│   │   │   │   ├── Admin.java                 # JPA Entity for MySQL 'admins' table
│   │   │   │   └── Donor.java                 # JPA Entity for MySQL 'donors' table
│   │   │   ├── repository/
│   │   │   │   ├── AdminRepository.java       # Spring Data JPA repository for Admin
│   │   │   │   └── DonorRepository.java       # Spring Data JPA repository for Donor
│   │   │   └── service/
│   │   │       ├── AdminUserDetailsService.java # Spring Security UserDetailsService
│   │   │       └── DonorService.java          # Core business logic & database queries
│   │   └── resources/
│   │       ├── static/
│   │       │   ├── css/
│   │       │   │   └── style.css              # Custom styling (Red #B91C1C theme)
│   │       │   └── js/
│   │       │       └── script.js              # Client helpers, search reset & alerts
│   │       ├── templates/
│   │       │   ├── about.html                 # Page 6: About Project
│   │       │   ├── admin-dashboard.html       # Page 5: Administrator Dashboard
│   │       │   ├── error.html                 # Friendly error page
│   │       │   ├── index.html                 # Page 1: Homepage
│   │       │   ├── login.html                 # Page 4: Administrator Login
│   │       │   ├── register.html              # Page 2: Donor Registration
│   │       │   └── search.html                # Page 3: Find Blood Donors
│   │       └── application.properties         # Database and server configuration
│   └── test/
│       ├── java/com/bloodconnect/
│       │   ├── BloodConnectApplicationTests.java # Context loading test
│       │   └── DonorWorkflowIntegrationTest.java # 12 Automated integration test cases
│       └── resources/
│           └── application.properties         # In-memory H2 database test configuration
├── .env.example                               # Example environment variables
├── pom.xml                                    # Maven dependencies & build settings
├── README.md                                  # Complete project documentation
├── sample-data.sql                            # 10 Fictional demonstration donor records
└── setup-database.sql                         # MySQL database & tables setup script
```

---

## 13. Database Table Structure

### Table 1: `donors`
Stores all registered blood donors.

| Column | Data Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | `BIGINT` | `PRIMARY KEY`, `AUTO_INCREMENT` | Unique donor ID |
| `full_name` | `VARCHAR(100)` | `NOT NULL` | Donor full name |
| `email` | `VARCHAR(150)` | `NOT NULL`, `UNIQUE` | Unique email address |
| `phone` | `VARCHAR(20)` | `NOT NULL` | Contact phone number |
| `blood_group` | `VARCHAR(10)` | `NOT NULL` | Blood group (`A+`, `O+`, etc.) |
| `city` | `VARCHAR(50)` | `NOT NULL` | City name |
| `availability` | `VARCHAR(20)` | `NOT NULL` (Default `'Available'`) | `'Available'` or `'Unavailable'` |
| `created_at` | `TIMESTAMP` | `NOT NULL`, `DEFAULT CURRENT_TIMESTAMP` | Registration timestamp |

### Table 2: `admins`
Stores administrator credentials for authentication.

| Column | Data Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | `BIGINT` | `PRIMARY KEY`, `AUTO_INCREMENT` | Unique administrator ID |
| `username` | `VARCHAR(100)` | `NOT NULL`, `UNIQUE` | Login username (e.g. `admin`) |
| `password` | `VARCHAR(255)` | `NOT NULL` | BCrypt encrypted password hash |
| `full_name` | `VARCHAR(100)` | `NULLABLE` | Admin display name |
| `role` | `VARCHAR(50)` | `NOT NULL` (Default `'ROLE_ADMIN'`) | Security role authority |

---

## 14. Common Errors and Their Solutions

### 1. `Communications link failure / Connection refused: connect`
- **Cause:** MySQL Server is not running or is listening on a different port.
- **Solution:** 
  1. Open Windows **Services** (`services.msc`), locate **MySQL80** (or **MySQL**), and click **Start**.
  2. Alternatively, in Administrator PowerShell:
     ```powershell
     Start-Service MySQL80
     ```

### 2. `Access denied for user 'root'@'localhost'`
- **Cause:** Incorrect MySQL password in `application.properties`.
- **Solution:** Pass the correct password via environment variable:
  ```powershell
  $env:DB_PASSWORD = "YourActualPassword"
  .\apache-maven-3.9.9\bin\mvn.cmd spring-boot:run
  ```

### 3. `Unknown database 'bloodconnect_db'`
- **Cause:** The database was not created before running the application.
- **Solution:** Run `setup-database.sql` in MySQL, or execute:
  ```sql
  CREATE DATABASE bloodconnect_db;
  ```
  *(The connection URL already includes `createDatabaseIfNotExist=true` to automatically create it if the MySQL user has permission).*

### 4. `Port 8080 was already in use`
- **Cause:** Another application or an existing instance of Spring Boot is running on port 8080.
- **Solution:** Either stop the existing process or run on another port:
  ```powershell
  $env:PORT = "8081"
  .\apache-maven-3.9.9\bin\mvn.cmd spring-boot:run
  ```
  Then visit [http://localhost:8081/](http://localhost:8081/).

### 5. `Invalid administrator credentials` on `/login`
- **Cause:** Typing wrong password or admin record was altered.
- **Solution:** Use the default credentials: `admin` / `Admin@123`.

---

## 15. Sample Demonstration Data

To populate 10 fictional donors for your viva/presentation:

```powershell
mysql -u root -p bloodconnect_db < sample-data.sql
```

> **Reminder:** All sample donor records in `sample-data.sql` use the `.test` email domain and are strictly fictional for demonstration.

---

## 16. College Viva / Interview Questions & Answers

1. **Why use Spring Boot for this project?**  
   *Spring Boot provides rapid application development with built-in Tomcat server, auto-configuration, dependency management, and production-ready defaults without XML configuration.*

2. **Why use Thymeleaf instead of JSP?**  
   *Thymeleaf is a modern natural templating engine. HTML templates can be previewed directly in a browser without a running server, and it provides seamless integration with Spring Security and Spring Form Binding.*

3. **How is donor privacy protected?**  
   *The public search results display only the donor's name, blood group, city, and availability. Direct phone numbers and email addresses are restricted to authenticated administrators who mediate emergency contact requests.*

4. **How are passwords secured?**  
   *Passwords are hashed using `BCryptPasswordEncoder` with salted cryptographic hashing before being saved to MySQL. Raw passwords are never stored in plain text.*
