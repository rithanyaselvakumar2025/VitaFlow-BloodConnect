-- ==============================================================================
-- BloodConnect – Sample Fictional Demonstration Data
--
-- IMPORTANT NOTICE:
-- The records in this file are entirely FICTIONAL and for academic testing and
-- college project demonstration purposes ONLY. None of these records represent
-- real individuals or real medical donors.
--
-- DO NOT automatically insert sample data into a database containing real records.
--
-- How to import this sample data in MySQL:
--   mysql -u root -p bloodconnect_db < sample-data.sql
-- ==============================================================================

USE bloodconnect_db;

-- Insert fictional donor records with varied blood groups, cities, and availability
INSERT INTO donors (full_name, email, phone, blood_group, city, availability, created_at)
VALUES
('Rahul Sharma', 'rahul.demo@bloodconnect.test', '+91 98765 43210', 'O+', 'Mumbai', 'Available', NOW()),
('Priya Patel', 'priya.demo@bloodconnect.test', '+91 98765 43211', 'A+', 'Delhi', 'Available', NOW()),
('Amit Verma', 'amit.demo@bloodconnect.test', '+91 98765 43212', 'B+', 'Bengaluru', 'Available', NOW()),
('Sneha Reddy', 'sneha.demo@bloodconnect.test', '+91 98765 43213', 'AB+', 'Hyderabad', 'Available', NOW()),
('Vikram Singh', 'vikram.demo@bloodconnect.test', '+91 98765 43214', 'O-', 'Mumbai', 'Available', NOW()),
('Ananya Iyer', 'ananya.demo@bloodconnect.test', '+91 98765 43215', 'A-', 'Chennai', 'Available', NOW()),
('Rohan Kulkarni', 'rohan.demo@bloodconnect.test', '+91 98765 43216', 'B-', 'Pune', 'Unavailable', NOW()),
('Neha Gupta', 'neha.demo@bloodconnect.test', '+91 98765 43217', 'AB-', 'Kolkata', 'Available', NOW()),
('Arjun Nair', 'arjun.demo@bloodconnect.test', '+91 98765 43218', 'O+', 'Bengaluru', 'Available', NOW()),
('Kavita Rao', 'kavita.demo@bloodconnect.test', '+91 98765 43219', 'A+', 'Mumbai', 'Unavailable', NOW());

SELECT '10 fictional demonstration donor records inserted successfully!' AS status;
